# -*- coding: utf-8 -*-
#"""
#Created on Sat Apr 21 21:10:07 2018
#
#@author: rskaddan
#pyton 2.7
#primary function is at the bottom of file

#Create the list of vehicles
#data is sorted by MMSI number and time.
#
#CONVERT RAW NUMBERS TO STANDARD UNIT (miles)
#untested code is still moving text around and not numbers
#
#this is a summary of available data, it is not live data
#NEXT STEP: create a function that uses this calculation on a new data entry
#            which isn't as computationally expensive
#            Use a boolean and make the estimate on known, and single added data
#"""
import csv
import math
import random
import time

#import pdb
#pdb.set_trace()

#-----------------------------------------------------------------------------
#Overlap of two circles that represents a ship crossing near a restricted area
#right now, A & B are just coordinates with 2 values each
def OverlapArea(A):
    #for loop to iterate through different B's
    with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/RegionsofInterst.csv','rb') as csvfile:
        csvReader = csv.reader(csvfile, delimiter=',')
        maxIntersect = 0
        for row in csvReader:
            try:
                B = [float(row[0]), float(row[1])]
                d = math.hypot(B[0] - A[0], B[1] - A[1])
                Ar = 0.2 #Aradius, ship area
                Br = 0.4 #Bradius, restricted area
                if (d <= Ar+Br): #if greater than restricted area + ship area, they arent touching
                    a = Ar*Ar #radius squared
                    b = Br*Br
            
                    x = (a - b + d * d) / (2 * d)
                    z = x * x
                    y = math.sqrt(abs(a - z))
            
                    if (d < abs(Br - Ar)):
                        maxIntersect = 100
                        #return math.pi * min(a, b)
                    
                    maxIntersect = max(maxIntersect, (a * math.asin(y / Ar) + b * math.asin(y / Br) - y * (x + math.sqrt(z + b - a))) / (math.pi*min(a,b)))
            
                maxIntersect = max(maxIntersect, 0)
            
            except ValueError:
                test3 = row
        csvfile.close()
    return maxIntersect/100
#-----------------------------------------------------------------------------
def genDirection(lstLat, lstLong, ndLat, ndLong):
    x = lstLong - ndLong
    y = lstLat - ndLat
    return math.atan2(y, x)*180/math.pi
#-----------------------------------------------------------------------------
def InCircle(vLat, vLon, rLat, rLon, rRadius):
    #take lat and long of input and run through list of regions
    x = vLon - rLon
    x2 = x*x
    y = vLat - rLat
    y2 = y*y
    if math.sqrt(x2+y2) <= rRadius:
        return 1
    return 0
#-----------------------------------------------------------------------------
def ROICheck(lat, lon):
    #check if points are in ROI
    with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/RegionsofInterst.csv','rb') as csvfile:
        csvReader = csv.reader(csvfile, delimiter=',')
        #firstLine = csvReader.readline()
        yn = 0
        for row in csvReader:
            try:
                #may have to insert a check to break before goin into other func
                rLat = float(row[0])
                rLon = float(row[1])
                yn = yn + InCircle(lat, lon, rLat, rLon, .4) #.14 is roughly a 10 mile radius
                
            except ValueError:
                test2 = row
        csvfile.close()
    return yn
        
def FirstCheck(lat, lon):
    RoI = ROICheck(lat, lon)
    
    #check if points are in Anchorage
    with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/AnchoragesLoc.csv','rb') as csvfile:
        csvReader = csv.reader(csvfile, delimiter=',')
        #firstLine = csvReader.readline()
        AncC = 0 #Anchorage Counter
        for row in csvReader:
            try:
                aLat = float(row[3])
                aLon = float(row[4])
                AncC = AncC + InCircle(lat, lon, aLat, aLon, .14) #.014 is roughly a 1 mile radius
                
            except ValueError, e:
                test2 = row
        csvfile.close()
    
    #check if points are in Port
    with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/PortLocations.csv','rb') as csvfile:
        csvReader = csv.reader(csvfile, delimiter=',')
        #firstLine = csvReader.readline()
        portC = 0
        for row in csvReader:
            try:
                pLat = float(row[0])
                pLon = float(row[1])
                portC = portC + InCircle(lat, lon, pLat, pLon, .07) #.007 is roughly a .5 mile radius
            
            except ValueError, e:
                test2 = row
        csvfile.close()
    
    return RoI, AncC, portC
#-----------------------------------------------------------------------------
def MCPred(vtype, speed, vdir, lat, lon):
    n = 1000 #number of repititions
    counter = 0
    #prediction is 10 min * speed in new direction
    for i in range(n):
        #changes speed and direction based on vessel type
        if vtype == 'LL':
            nspeed = speed + random.uniform(-2,2)
            ndir = vdir + random.uniform(-25, 25)
        if vtype == 'TR':
            if random.uniform(0,1) > .5:
                nspeed = speed + random.uniform(-2, 2)
            else:
                nspeed = .01
            ndir = vdir + random.uniform(-135, 135)
        else:
            nspeed = speed + random.uniform(-3,3)
            ndir = vdir + random.uniform(0, 360)
        #uses new speed and direction to find new lat and Long
        #knot is 1.852 km/h or 1.15078 mph
        hyp = nspeed * 1.15078 / 6 #speed (knots) * 1.15078 (miles) * 1/6 (10 min)
        turn = ndir * math.pi/180
        nlat = lat + hyp*math.sin(turn)
        #not accounting for variance in lat because of randomness of prediction
        nlon = lon + hyp*math.cos(turn)
        #checks new lat and lon to see if there is intersection in POI
        if ROICheck(nlat, nlon) == 1:
            counter = counter + 1
            
    return counter/n
#-----------------------------------------------------------------------------
def IOMC(L): #Run the InOut Model, and MonteCarlo Prediction
    FlaggedROI = []
    FlaggedAnc = []
    FlaggedPor = []
    prevArray = None
    print len(L)
    for vDta in L:
        vLat = float(vDta[2])
        vLon = float(vDta[3])
        #check if points are in ROI, check if points are in Anchorage, check if points are in Port
        ROIval, Anchval, Portval = FirstCheck(vLat, vLon)
        if ROIval >= 1:
            FlaggedROI.append([vLat, vLon, ROIval])
        if Anchval >= 1:
            FlaggedAnc.append([vLat, vLon, Anchval])
        if Portval >= 1:
            FlaggedPor.append([vLat, vLon, Portval])
        
        #need prev value for midpoints
        if prevArray != None:
            midLat = (prevArray[0] + vLat) * .5
            midLon = (prevArray[1] + vLon) * .5
            dngr = OverlapArea([midLat, midLon])
            if dngr > 0:
                FlaggedROI.append([midLat, midLon, dngr])
        prevArray = [vLat, vLon]
        
    #THINKING ABOUT A PORT COUNT, ANCHORAGE COUNT, and something for ROI
    #Now I have a list of locations, 
    HighROImax = []
    HighROIcntr = 0 #counts how many values are above 30%
    if FlaggedROI != []:
        for j in FlaggedROI:
            if j[2] > .3:
                HighROIcntr = HighROIcntr + 1
            if HighROImax != []:
                if HighROImax[2] < j[2]:
                    HighROImax = j
            else:
                HighROImax = j
        
    #should have a check to determine the largest timestamp,
    #   Just assuming dataset is sorted...
    lstLat = float(L[len(L)-1][2])
    lstLon = float(L[len(L)-1][3])
    if len(L) == 1: #if there is only one datapoint for a vessel
        #makes the direction say they are heading West
        ndLat = float(L[len(L)-1][2]) + 0.001
        ndLon = float(L[len(L)-1][3]) + 0.0001
    else:
        ndLat = float(L[len(L)-2][2])
        ndLon = float(L[len(L)-2][3])
    vDir = genDirection(lstLat, lstLon, ndLat, ndLon)
    vtype = L[len(L)-1][4]
    speed = float(L[len(L)-1][1])
    print 'Starting Monte Carlo'
    #print ndLat, ndLon
    #print lstLat, lstLon
    MCpercent = MCPred(vtype, speed, vDir, lstLat, lstLon)
    
    return HighROImax, HighROIcntr, len(FlaggedAnc), len(FlaggedPor), MCpercent
#-----------------------------------------------------------------------------
def BNrank(PercentOvrlap, NumOverlap, AncNum, PortNum, MC): #Bayesian Net ranking function for sum of components
    Score = 30 * PercentOvrlap + 2.5 * min(NumOverlap, 10) + 1 * \
    min(AncNum, 10) + 1.5 * min(PortNum, 10) + 20 * MC
    #.3 overlap, .25 numOverlap, .1 Anchorage, .15 Port, .2 MC
    return Score
#-----------------------------------------------------------------------------
# {MMSI:[[Timestamp, Speed, Latiutude, Longitude, Vessel Type]]}
counter = 0
vesselDict = {} #Verssel Data From Scrubbed Data
vInOutScore = {} #Vesel ID with % overlap
vMonteCScore = {}
vImportance = {}
with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/CondensedCSV.csv','rb') as csvfile:
    csvReader = csv.reader(csvfile, delimiter=',')
    #firstLine = csvReader.readline()
    for row in csvReader:
        try:
            tryCheck = float(row[0]) #this will skip the headder row, by failing to convert a string to a number
            test = row[1]
            if vesselDict.get(test) == None:
                newD = {row[1]:[[row[0], row[5], row[3], row[4], row[2]]]}
                vesselDict.update(newD)
                counter = counter + 1
            else:
                dta = vesselDict[row[1]]
                newdta = [row[0], row[5], row[3], row[4], row[2]]
                dta.append(newdta)
                newD = {row[1]:dta}
                vesselDict.update(newD)
        except ValueError, e:
            print row
    csvfile.close()

print vesselDict.keys()
#print vesselDict.keys()[0]

for vID in vesselDict.keys():
    start_time = time.time()
    WarnROI, g30Overlap, AncNum, PortNum, futurePred = IOMC(vesselDict[vID])
    pctOvlap = 0
    if WarnROI != []:
        pctOvlap = WarnROI[2]
    rank = BNrank(pctOvlap, g30Overlap, AncNum, PortNum, futurePred)
    vImportance.update({vID:rank})
    
    print WarnROI
    if WarnROI != []:
        print vID, ': IO=', WarnROI[2], 'numROI intersect:', g30Overlap,' MC=', futurePred
    else:
        print vID, ': IO=', 'No Intersect', 'numROI intersect:', g30Overlap,' MC=', futurePred
    print 'Anchorage Counter:', AncNum, 'Number of Ports Visited:', PortNum
    print 'Runtime: ', time.time() - start_time
    print '----------'
        
print vImportance
#need a function that receives the Dict list with positions
#calculates inoutScore, and future prediction score

#59.14, -178.282