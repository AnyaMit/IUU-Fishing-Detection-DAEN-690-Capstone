# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a script that finds data within a region (quadrent of the globe)
and outputs the usable data

THE DATA FILES ARE TOO LARGE TO UPLOAD TO GITHUB
DOWNLOAD THESE FILES:
    kr_LL1_all
    kr_ps_ass-003
    kr_tr1_all
    
    Feel free to contact me at ray.skaddan@gmail.com
    
Unfortunately the output has spaces between each line, so the file needs to be 
    filtered to remove the spaces
"""

import csv
count1 = 0

latmin = -180
latmax = -90
lonmin = 10
lonmax = 60

mmsiCounter = {}

tCheck = "" #Check prev timestamp
mCheck = "" #Check prev MMSI
with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/CondensedCSV.csv', 'w') as f:
    thewrite = csv.writer(f)
    thewrite.writerow(['Timestamp', 'MMSI', 'Vessel Type', 'Latitude', 'Longitude', 'Speed'])
        
    print 'starting...'
    with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/ScrubData/kr_LL1_all.csv','rb') as csvfile:
    #with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/kr_tr1_all.csv','rb') as csvfile:
    #with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/kr_ps_all-003.csv','rb') as csvfile:
        csvReader = csv.reader(csvfile, delimiter=',')
        #firstLine = csvReader.readline()
        for row in csvReader:
            #checking longitude
            
            try:
                if row[19] == tCheck and row[35] == mCheck:
                    test = 0
                else:
                    if latmin < float(row[55]) < latmax:
                        #print row[89]
                        if lonmin < float(row[89]) < lonmax:
                            #print row[35]
                            test1 = row[35]
                            if mmsiCounter.get(test1) == None:
                                newD = {test1:1}
                                mmsiCounter.update(newD)
                            else:
                                dta = mmsiCounter[test1] + 1
                                newD = {test1:dta}
                                mmsiCounter.update(newD)
                            if mmsiCounter[test1] < 400:
                                thewrite.writerow([row[19], row[35], 'LL', row[89], row[55], row[8]])
                                tCheck = row[19]
                                mCheck = row[35]
                                count1 = count1 + 1
                            
            except ValueError, e:
                #print row
                print row[19] + ' ' + row[35] + ' ' + row[55] + ' ' + row[89]
        csvfile.close()
        print 'Section 1...Complete', count1, 'Added'
        
    with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/ScrubData/kr_tr1_all.csv','rb') as csvfile:
        csvReader = csv.reader(csvfile, delimiter=',')
        #firstLine = csvReader.readline()
        for row in csvReader:
            #checking longitude
            #print row[55]
            try:
                if row[19] == tCheck and row[35] == mCheck:
                    test = 1
                else:
                    if latmin < float(row[55]) < latmax:
                        #print row[89]
                        if lonmin < float(row[89]) < lonmax:
                            test1 = row[35]
                            if mmsiCounter.get(test1) == None:
                                newD = {test1:1}
                                mmsiCounter.update(newD)
                            else:
                                dta = mmsiCounter[test1] + 1
                                newD = {test1:dta}
                                mmsiCounter.update(newD)
                            if mmsiCounter[test1] < 400:
                                thewrite.writerow([row[19], row[35], 'TR', row[89], row[55], row[8]])
                                tCheck = row[19]
                                mCheck = row[35]
                                count1 = count1 + 1
                        
            except ValueError, e:
                #print row
                print row[19] + ' ' + row[35] + ' ' + row[55] + ' ' + row[89]
        csvfile.close()
        print 'Section 2...Complete', count1, 'Added'
        
    with open('C:/Users/rskaddan/Documents/George Mason University/Spring2018/SYST699/PythonCode/ScrubData/kr_ps_all-003.csv','rb') as csvfile:
        csvReader = csv.reader(csvfile, delimiter=',')
        #firstLine = csvReader.readline()
        for row in csvReader:
            #checking longitude
            #print row[55]
            try:
                if row[19] == tCheck and row[35] == mCheck:
                    test = 2
                else:
                    if latmin < float(row[55]) < latmax:
                        #print row[89]
                        if lonmin < float(row[89]) < lonmax:
                            test1 = row[35]
                            if mmsiCounter.get(test1) == None:
                                newD = {test1:1}
                                mmsiCounter.update(newD)
                            else:
                                dta = mmsiCounter[test1] + 1
                                newD = {test1:dta}
                                mmsiCounter.update(newD)
                            if mmsiCounter[test1] < 400:
                                thewrite.writerow([row[19], row[35], 'PS', row[89], row[55], row[8]])
                                tCheck = row[19]
                                mCheck = row[35]
                                count1 = count1 + 1
                        
            except ValueError, e:
                #print row
                print row[19] + ' ' + row[35] + ' ' + row[55] + ' ' + row[89]
        csvfile.close()
        print 'Section 3...Complete', count1, 'Added'
        
f.close()
print count1, 'Enteries Added'
# need column 19 (timestamp), 35 (mmsi), 55 (lon), 89 (lat) 
# column 8 (speed), 47 (classsification) [1,0,-1], 